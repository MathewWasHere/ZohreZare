/* ==========================================================================
   booking.js — جریان رزرو نوبت
   گام ۱ خدمت → گام ۲ روز و ساعت → گام ۳ تایید → گام ۴ نتیجه

   انتخاب ناتمام کاربر در حافظه ذخیره می‌شود تا اگر برای ورود به صفحه‌ی
   احراز هویت رفت، بعد از برگشت همه‌چیز سر جایش باشد.
   ========================================================================== */
(function (global) {
  'use strict';

  var ZZ = global.ZZ;
  var u = ZZ.u;
  var CUR = ZZ.config.booking.currency;
  var DRAFT_KEY = 'bookingDraft';

  var STEPS = [
    { id: 'panelService', label: 'خدمت' },
    { id: 'panelTime',    label: 'زمان' },
    { id: 'panelConfirm', label: 'تایید' },
    { id: 'panelDone',    label: 'ثبت' }
  ];

  var state = {
    step: 0,
    serviceId: null,
    variantId: null,
    date: null,
    time: null,
    note: ''
  };

  /* ---------------- پیش‌نویس ---------------- */
  function saveDraft() {
    ZZ.store.set(DRAFT_KEY, {
      serviceId: state.serviceId,
      variantId: state.variantId,
      date: state.date,
      time: state.time,
      note: state.note,
      step: Math.min(state.step, 2)
    });
  }
  function loadDraft() {
    var d = ZZ.store.get(DRAFT_KEY, null);
    if (!d) return null;
    /* اگر روز انتخاب‌شده گذشته باشد، زمان را دور می‌ریزیم */
    if (d.date && u.isPast(d.date, d.time)) { d.date = null; d.time = null; d.step = Math.min(d.step, 1); }
    return d;
  }
  function clearDraft() { ZZ.store.remove(DRAFT_KEY); }

  /* ---------------- نوار مراحل ---------------- */
  function renderSteps() {
    var bar = u.$('#stepsBar');
    bar.innerHTML = STEPS.map(function (s, i) {
      var cls = i === state.step ? ' is-active' : (i < state.step ? ' is-done' : '');
      return '<span class="step' + cls + '" role="listitem">' +
               '<span class="step__num">' + (i < state.step ? ZZ.icon('check', null, 14) : u.toFa(i + 1)) + '</span>' +
               '<span>' + s.label + '</span>' +
             '</span>' +
             (i < STEPS.length - 1 ? '<span class="step__line"></span>' : '');
    }).join('');
  }

  function goStep(n) {
    state.step = n;
    u.$$('.book-panel').forEach(function (p) { p.classList.remove('is-active'); });
    u.$('#' + STEPS[n].id).classList.add('is-active');
    renderSteps();
    if (n < 3) saveDraft();

    /* نوار چسبان تا ثبت نهایی زیر انگشت می‌ماند؛ روی صفحه‌ی موفقیت
       دیگر دکمه‌ای لازم نیست. */
    var cta = u.$('#bookCta');
    if (cta) cta.hidden = n === 3;
    updateCtaBar();

    var top = u.$('#stepsBar').getBoundingClientRect().top + global.scrollY - 90;
    global.scrollTo({ top: Math.max(0, top), behavior: 'smooth' });
  }

  /* ---------------- نوار چسبان پایین ----------------
     دکمه‌ی اصلی هر گام + خلاصه‌ی انتخاب (قیمت یا زمان) همیشه در دسترسِ
     شست کاربر است؛ لازم نیست تا انتهای صفحه اسکرول کند. */
  function ctaState() {
    var s = ZZ.services.getById(state.serviceId);
    var v = s ? ZZ.services.getVariant(state.serviceId, state.variantId) : null;
    var approve = ZZ.config.approval && ZZ.config.approval.enabled;

    if (state.step === 0) {
      return {
        label: 'ادامه: انتخاب زمان',
        disabled: !(state.serviceId && state.variantId),
        info: v
          ? u.esc(v.name) + ' · ' + u.money(v.price) + ' ' + CUR + ' · ' + u.duration(v.durationMin)
          : 'اول خدمت و گزینه‌ی دقیق را انتخاب کنید'
      };
    }

    if (state.step === 1) {
      var d = state.date ? u.fromKey(state.date) : null;
      return {
        label: 'ادامه: بررسی نهایی',
        disabled: !(state.date && state.time),
        info: (d && state.time)
          ? u.esc(u.faDate(d, true)) + ' · ساعت ' + u.toFa(state.time)
          : 'روز و ساعت را انتخاب کنید'
      };
    }

    /* گام بررسی نهایی */
    return {
      label: ZZ.auth.isLoggedIn()
        ? (approve ? 'ثبت درخواست نوبت' : 'ثبت نهایی نوبت')
        : (approve ? 'ورود و ثبت درخواست' : 'ورود و ثبت نوبت'),
      disabled: false,
      info: v ? 'مبلغ تقریبی: ' + u.money(v.price) + ' ' + CUR : ''
    };
  }

  function updateCtaBar() {
    var btn = u.$('#ctaBtn');
    var info = u.$('#ctaInfo');
    if (!btn || !info) return;
    var c = ctaState();
    btn.textContent = c.label;
    btn.disabled = c.disabled;
    info.innerHTML = c.info;
  }



  /* ---------------- گام ۱: خدمت ---------------- */
  function renderServices() {
    var box = u.$('#serviceChoices');
    box.innerHTML = ZZ.services.getAll().map(function (s) {
      return '' +
        '<label class="choice">' +
          '<input type="radio" name="service" value="' + s.id + '"' +
            (state.serviceId === s.id ? ' checked' : '') + '>' +
          '<span class="choice__box">' +
            '<span style="flex-shrink:0;width:40px;height:40px;display:grid;place-items:center;' +
                  'border-radius:50%;background:var(--blush-100);color:var(--rose-500);">' +
              ZZ.icon(s.icon, null, 20) + '</span>' +
            '<span style="flex:1;min-width:0;">' +
              '<span class="choice__title">' + u.esc(s.title) + '</span><br>' +
              '<span class="choice__meta">' + u.esc(s.short) + '</span>' +
            '</span>' +
          '</span>' +
        '</label>';
    }).join('');

    box.addEventListener('change', function (e) {
      if (e.target.name !== 'service') return;
      state.serviceId = e.target.value;
      state.variantId = null;
      state.date = null;
      state.time = null;
      renderVariants();
      updateStep1Button();
      saveDraft();
    });
  }

  function renderVariants() {
    var wrap = u.$('#variantWrap');
    var box = u.$('#variantChoices');
    var s = ZZ.services.getById(state.serviceId);

    if (!s) { wrap.hidden = true; box.innerHTML = ''; return; }
    wrap.hidden = false;

    box.innerHTML = s.variants.map(function (v) {
      return '' +
        '<label class="choice">' +
          '<input type="radio" name="variant" value="' + v.id + '"' +
            (state.variantId === v.id ? ' checked' : '') + '>' +
          '<span class="choice__box">' +
            '<span style="flex:1;min-width:0;">' +
              '<span class="choice__title">' + u.esc(v.name) + '</span><br>' +
              '<span class="choice__meta">' + u.esc(v.note || '') + '</span>' +
            '</span>' +
            '<span style="flex-shrink:0;text-align:left;">' +
              '<span style="display:block;font-weight:500;color:var(--rose-600);white-space:nowrap;">' +
                u.money(v.price) + ' ' + CUR + '</span>' +
              '<span style="display:block;font-size:var(--fs-xs);color:var(--text-muted);white-space:nowrap;">' +
                u.duration(v.durationMin) + '</span>' +
            '</span>' +
          '</span>' +
        '</label>';
    }).join('');
  }

  function updateStep1Button() { updateCtaBar(); }

  /* ---------------- گام ۲: روز و ساعت ---------------- */
  function renderDays() {
    var strip = u.$('#dayStrip');
    /* در حالت بک‌اند، کش تقویم ممکن است برای پنل مدیریت بازتر باشد
       (مثلاً ۶۰ روز)؛ نوار مشتری همیشه فقط به اندازه‌ی تنظیمات نشان
       می‌دهد تا صفحه شلوغ نشود. */
    var days = ZZ.appointments.getDays().slice(0, ZZ.config.booking.daysAhead);

    /* تقویم هفت‌ستونه — بدون اسکرول افقی: ۱۴ روز در دو ردیف.
       زیر هر روز تعداد ساعت‌های خالی دیده می‌شود تا کاربر سراغ
       روزِ پر نشود؛ روزهای تکمیل هم صریح نوشته می‌شوند. */
    strip.innerHTML = days.map(function (d, i) {
      var openCount = d.closed ? 0 : ZZ.appointments.getSlots(d.key, state.serviceId)
        .filter(function (s) { return s.available; }).length;
      var open = openCount > 0;
      var sel = state.date === d.key;
      var title = d.closed ? 'تعطیل' : (open ? d.label : 'ظرفیت این روز تکمیل است');
      /* دو روز اول با نام کامل (امروز/فردا)؛ بقیه با حرف روز هفته،
         چون خانه‌ها ۷تایی باریک‌اند */
      var dayLbl = i < 2 ? u.esc(d.label) : u.esc(u.faWeekdayShort(d.date));
      return '<button type="button" class="day-chip' + (sel ? ' is-selected' : '') + '" ' +
               'data-date="' + d.key + '" title="' + u.esc(title) + '"' + (open ? '' : ' disabled') + '>' +
               '<span class="day-chip__day">' + dayLbl + '</span>' +
               '<span class="day-chip__date">' + u.esc(d.closed ? 'تعطیل' : d.short) + '</span>' +
               (open
                 ? '<span class="day-chip__cnt">' + u.toFa(openCount) + ' ساعت</span>'
                 : (d.closed ? '' : '<span class="day-chip__cnt is-full">تکمیل</span>')) +
             '</button>';
    }).join('');

    /* اگر روزی انتخاب نشده، اولین روز باز را بردار */
    if (!state.date) {
      var first = days.filter(function (d) {
        return !d.closed && ZZ.appointments.hasOpenSlot(d.key, state.serviceId);
      })[0];
      if (first) {
        state.date = first.key;
        var btn = strip.querySelector('[data-date="' + first.key + '"]');
        if (btn) btn.classList.add('is-selected');
      }
    }
  }

  function renderSlots() {
    var grid = u.$('#slotGrid');
    var empty = u.$('#slotEmpty');

    if (!state.date) {
      grid.innerHTML = '';
      empty.innerHTML = '<p class="muted" style="font-size:var(--fs-sm);">ابتدا یک روز انتخاب کنید.</p>';
      return;
    }

    var slots = ZZ.appointments.getSlots(state.date, state.serviceId);
    var open = slots.filter(function (s) { return s.available; });

    if (!open.length) {
      grid.innerHTML = '';
      empty.innerHTML = '<div class="note note--warn">' + ZZ.icon('info') +
        '<span>این روز ظرفیت خالی ندارد. لطفاً روز دیگری را امتحان کنید یا با ما تماس بگیرید.</span></div>';
      return;
    }

    empty.innerHTML = '';
    grid.innerHTML = slots.map(function (s) {
      var sel = state.time === s.time;
      return '<button type="button" class="slot' + (sel ? ' is-selected' : '') + '" ' +
               'data-time="' + s.time + '"' + (s.available ? '' : ' disabled') + '>' +
               u.toFa(s.time) +
               (s.reason ? '<small>' + u.esc(s.reason) + '</small>' : '') +
             '</button>';
    }).join('');
  }

  function updateStep2Button() { updateCtaBar(); }

  /* ---------------- گام ۳: خلاصه ---------------- */
  function summaryHTML() {
    var s = ZZ.services.getById(state.serviceId);
    var v = ZZ.services.getVariant(state.serviceId, state.variantId);
    if (!s || !v) return '';

    var d = u.fromKey(state.date);
    var rows = [
      ['خدمت', u.esc(s.title)],
      ['گزینه', u.esc(v.name)],
      ['روز', u.esc(u.faDate(d, true))],
      ['ساعت', u.toFa(state.time)],
      ['مدت تقریبی', u.duration(v.durationMin)]
    ];
    if (state.note) rows.push(['توضیح شما', u.esc(state.note)]);

    return '<dl style="margin:0;">' +
      rows.map(function (r) {
        return '<div class="summary__row"><dt>' + r[0] + '</dt><dd>' + r[1] + '</dd></div>';
      }).join('') +
      '</dl>' +
      '<div class="summary__total">' +
        '<span>مبلغ تقریبی</span>' +
        '<strong>' + u.money(v.price) + ' ' + CUR + '</strong>' +
      '</div>' +
      '<p class="muted" style="font-size:var(--fs-xs);margin-top:var(--sp-3);margin-bottom:0;line-height:1.85;">' +
        ((ZZ.config.approval && ZZ.config.approval.enabled)
          ? 'با ثبت درخواست، این ساعت برای شما نگه داشته می‌شود و همکاران ما برای ' +
            'هماهنگی نهایی با شما تماس می‌گیرند. پرداخت در محل انجام می‌شود و مبلغ ' +
            'نهایی ممکن است بعد از مشاوره‌ی حضوری کمی تغییر کند.'
          : 'پرداخت در محل انجام می‌شود. مبلغ نهایی ممکن است بعد از مشاوره‌ی حضوری کمی تغییر کند.') +
      '</p>';
  }

  function renderConfirm() {
    u.$('#summaryBox').innerHTML = summaryHTML();

    var notice = u.$('#authNotice');

    if (ZZ.auth.isLoggedIn()) {
      var user = ZZ.auth.currentUser();
      notice.innerHTML = '<div class="note note--ok">' + ZZ.icon('checkCircle') +
        '<span>به‌عنوان <strong class="ltr phone-num">' + u.prettyPhoneHTML(user.phone) + '</strong> وارد شده‌اید.</span></div>';
    } else {
      notice.innerHTML = '<div class="note note--info">' + ZZ.icon('info') +
        '<span>برای ثبت نوبت، شماره‌ی موبایل خود را تایید کنید. با زدن دکمه‌ی زیر ' +
        'همان‌جا و بدون ترک این صفحه کد را وارد می‌کنید؛ انتخاب‌هایتان حفظ می‌شود.</span></div>';
    }

    updateCtaBar();
  }

  /* ---------------- ورود در همان صفحه ----------------
     به‌جای پرتاب کاربر به صفحه‌ی ورود، شماره و کد همان‌جا در یک پنجره
     گرفته می‌شود؛ خلاصه‌ی نوبت زیر پنجره سر جایش می‌ماند و کاربر
     هیچ‌وقت حس «از جریان خارج شدم» نمی‌گیرد. */
  function openLoginDialog() {
    var apiRef = null;

    function showErr(host, msg) {
      var err = u.$('#dlgErr', host);
      err.textContent = msg;
      err.hidden = false;
    }

    /* یک مرحله: شماره → کد. با «تایید» پیش می‌رود و پنجره تا رسیدن
       به نتیجه باز می‌ماند (onConfirm همیشه false برمی‌گرداند). */
    function stage(host, api) {
      var btn = u.$('[data-confirm]', host);
      var err = u.$('#dlgErr', host);
      err.hidden = true;

      /* --- مرحله‌ی ۱: گرفتن کد برای شماره --- */
      if (u.$('#dlgStep2', host).hidden) {
        btn.classList.add('is-loading');
        ZZ.auth.requestCode(u.$('#dlgPhone', host).value)
          .then(function (res) {
            btn.classList.remove('is-loading');
            u.$('#dlgStep2', host).hidden = false;
            btn.textContent = 'تایید و ثبت نوبت';
            u.$('#dlgCode', host).focus();

            /* حالت نمایشی: کد روی صفحه نشان داده می‌شود */
            var demo = u.$('#dlgDemo', host);
            if (demo) {
              if (res && res.code) {
                demo.textContent = 'کد نمایشی: ' + u.toFa(res.code);
                demo.hidden = false;
              } else {
                demo.hidden = true;
              }
            }
          })
          .catch(function (e) {
            btn.classList.remove('is-loading');
            showErr(host, (e && e.message) || 'ارسال کد ناموفق بود.');
            u.$('#dlgPhone', host).focus();
          });
        return false;
      }

      /* --- مرحله‌ی ۲: تایید کد --- */
      btn.classList.add('is-loading');
      ZZ.auth.verifyCode(u.$('#dlgCode', host).value)
        .then(function () {
          api.close(true);
        })
        .catch(function (e) {
          btn.classList.remove('is-loading');
          showErr(host, (e && e.message) || 'کد تایید نشد.');
          u.$('#dlgCode', host).focus();
        });
      return false;
    }

    return ZZ.dialog.open({
      title: 'تایید شماره موبایل',
      hint: 'برای ثبت نوبت فقط شماره‌ی موبایل لازم است.',
      body:
        '<div class="login-box">' +
          '<label class="field"><span class="field__label" for="dlgPhone">شماره موبایل</span>' +
          '<input class="input ltr phone-num" id="dlgPhone" type="tel" inputmode="tel" ' +
            'autocomplete="tel" placeholder="09…" maxlength="14"></label>' +
          '<div id="dlgStep2" hidden>' +
            '<label class="field"><span class="field__label" for="dlgCode">کد تایید پیامک‌شده</span>' +
            '<input class="input ltr" id="dlgCode" type="text" inputmode="numeric" ' +
              'autocomplete="one-time-code" maxlength="6" placeholder="----"></label>' +
            '<p class="login-box__links">' +
              '<button type="button" class="linklike" id="dlgResend">ارسال دوباره‌ی کد</button>' +
              '<button type="button" class="linklike" id="dlgChange">تغییر شماره</button>' +
            '</p>' +
          '</div>' +
          '<p class="login-box__demo" id="dlgDemo" hidden></p>' +
          '<p class="login-box__err" id="dlgErr" role="alert" hidden></p>' +
        '</div>',
      confirmLabel: 'دریافت کد',
      cancelLabel: 'انصراف',
      onMount: function (host, api) {
        apiRef = api;

        var phone = u.$('#dlgPhone', host);
        var confirmBtn = u.$('[data-confirm]', host);

        /* Enter در هر فیلد یعنی همان کلیک روی «تایید» */
        [phone, u.$('#dlgCode', host)].forEach(function (el) {
          el.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
              e.preventDefault();
              confirmBtn.click();
            }
          });
        });

        u.$('#dlgResend', host).addEventListener('click', function () {
          u.$('#dlgErr', host).hidden = true;
          stage(host, api);
        });
        u.$('#dlgChange', host).addEventListener('click', function () {
          u.$('#dlgErr', host).hidden = true;
          u.$('#dlgDemo', host).hidden = true;
          u.$('#dlgStep2', host).hidden = true;
          confirmBtn.textContent = 'دریافت کد';
          phone.focus();
        });

        setTimeout(function () { if (phone) phone.focus(); }, 60);
      },
      onConfirm: function (host) {
        return stage(host, apiRef);
      }
    });
  }

  /* ---------------- صفحه‌ی موفقیت ---------------- */

  /** کد کوتاه پیگیری — از شناسه‌ی نوبت ساخته می‌شود تا مشتری هنگام
      تماس سالن به آن اشاره کند و طرفین همان نوبت را منظور کنند */
  function trackCode(id) {
    var s = u.toEn(String(id || '')).replace(/[^0-9a-zA-Z]/g, '');
    return s.slice(-6).toUpperCase() || '—';
  }

  /** فایل تقویم (iCal) — کاملاً در مرورگر ساخته می‌شود؛ بدون سرویس
      بیرونی. تاریخ‌ها محلی‌اند (بدون TZ) که تقویم گوشی خودش درست
      تفسیر می‌کند. */
  function buildICS(appt) {
    var s = ZZ.services.getById(appt.serviceId);
    var v = ZZ.services.getVariant(appt.serviceId, appt.variantId);
    var dur = (v && v.durationMin) || appt.durationMin || 90;

    var start = u.fromKey(appt.date);
    var hm = String(appt.time).split(':');
    start.setHours(+hm[0] || 0, +hm[1] || 0, 0, 0);
    var end = new Date(start.getTime() + dur * 60000);

    function stamp(d) {
      return d.getFullYear() +
        String(d.getMonth() + 1).padStart(2, '0') +
        String(d.getDate()).padStart(2, '0') + 'T' +
        String(d.getHours()).padStart(2, '0') +
        String(d.getMinutes()).padStart(2, '0') + '00';
    }
    function escIcs(t) {
      return String(t == null ? '' : t)
        .replace(/\\/g, '\\\\').replace(/;/g, '\\;')
        .replace(/,/g, '\\,').replace(/\n/g, '\\n');
    }

    var brand = ZZ.config.brand || {};
    var addr = brand.address || '';

    return [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//ZohreZare//Booking//FA',
      'CALSCALE:GREGORIAN',
      'BEGIN:VEVENT',
      'UID:' + appt.id + '@zohrezare',
      'DTSTAMP:' + stamp(new Date()),
      'DTSTART:' + stamp(start),
      'DTEND:' + stamp(end),
      'SUMMARY:' + escIcs((s ? s.title : 'نوبت') + (v ? ' — ' + v.name : '') + ' | ' + (brand.name || '')),
      'LOCATION:' + escIcs(addr),
      'DESCRIPTION:' + escIcs('کد پیگیری: ' + trackCode(appt.id) +
        (appt.note ? '\nتوضیح: ' + appt.note : '')),
      'END:VEVENT',
      'END:VCALENDAR'
    ].join('\r\n');
  }

  /** کد پیگیری + آدرس + مسیریابی + «افزودن به تقویم» */
  function renderDoneExtras(appt) {
    var box = u.$('#doneDetails');
    var icsBtn = u.$('#icsBtn');
    var brand = ZZ.config.brand || {};
    var addr = brand.address || '';
    var addrShort = brand.addressShort || addr;
    var geo = brand.geo;
    var code = trackCode(appt.id);

    box.innerHTML =
      '<div class="done-meta__row">' +
        '<span class="done-meta__lbl">کد پیگیری</span>' +
        '<strong class="done-meta__val ltr" dir="ltr">' + u.esc(code) + '</strong>' +
      '</div>' +
      '<div class="done-meta__row">' +
        '<span class="done-meta__lbl">آدرس سالن</span>' +
        '<span class="done-meta__val">' + u.esc(addrShort) + '</span>' +
      '</div>' +
      (addr
        ? '<a class="done-meta__map" href="https://maps.google.com/?q=' +
            encodeURIComponent(geo ? (geo.lat + ',' + geo.lng) : addr) + '" ' +
            'target="_blank" rel="noopener">' + ZZ.icon('pin', null, 15) + 'مسیریابی</a>'
        : '');

    /* «افزودن به تقویم» فقط جایی که مرورگر از Blob پشتیبانی می‌کند */
    if (global.Blob && global.URL && global.URL.createObjectURL) {
      icsBtn.hidden = false;
      icsBtn.innerHTML = ZZ.icon('calendarPlus', null, 16) + 'افزودن به تقویم';
      icsBtn.onclick = function () {
        var blob = new global.Blob([buildICS(appt)], { type: 'text/calendar;charset=utf-8' });
        var url = global.URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'nobat-' + code + '.ics';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { global.URL.revokeObjectURL(url); }, 2000);
        ZZ.toast.ok('به تقویمتان اضافه شد');
      };
    }
  }

  /* ---------------- ثبت نهایی ---------------- */
  function submit() {
    var btn = u.$('#ctaBtn');

    /* اگر وارد نشده: ورود در همان صفحه (پنجره‌ی شماره و کد)؛
       پیش‌نویس هم ذخیره می‌شود تا اگر اتفاقی افتاد، همه‌چیز در امان باشد */
    if (!ZZ.auth.isLoggedIn()) {
      saveDraft();
      openLoginDialog().then(function (ok) {
        if (!ok) return;
        renderConfirm();   /* اطلاعِ «وارد شدید» تازه شود */
        submit();          /* و ثبت، همان‌جا ادامه پیدا کند */
      });
      return;
    }

    btn.classList.add('is-loading');

    ZZ.appointments.create({
      serviceId: state.serviceId,
      variantId: state.variantId,
      date: state.date,
      time: state.time,
      note: state.note
    })
      .then(function (appt) {
        btn.classList.remove('is-loading');
        clearDraft();

        var d = u.fromKey(appt.date);
        var pending = appt.status === 'pending';
        var respHours = (ZZ.config.approval && ZZ.config.approval.responseHours) || 6;

        var title = u.$('#doneTitle');
        if (title) {
          title.textContent = pending ? 'درخواستتان ثبت شد' : 'نوبتتان ثبت شد';
        }
        u.$('#doneText').textContent = pending
          ? u.faDate(d) + ' ساعت ' + u.toFa(appt.time) + ' برای شما نگه داشته شد. ' +
            'تا حدود ' + u.toFa(respHours) + ' ساعت آینده برای هماهنگی نهایی با شما تماس می‌گیریم.'
          : 'منتظرتان هستیم؛ ' + u.faDate(d) + ' ساعت ' + u.toFa(appt.time) + '.';
        u.$('#doneSummary').innerHTML = summaryHTML();
        renderDoneExtras(appt);

        goStep(3);
        ZZ.toast.ok(pending ? 'درخواست شما ثبت شد' : 'نوبت شما با موفقیت ثبت شد');
      })
      .catch(function (err) {
        btn.classList.remove('is-loading');
        ZZ.toast.error(err.message);
        /* اگر بازه پر شده بود، برگرد به انتخاب زمان */
        if (/در دسترس نیست/.test(err.message)) {
          state.time = null;
          renderDays();
          renderSlots();
          updateStep2Button();
          goStep(1);
        }
      });
  }

  /* ---------------- راه‌اندازی ---------------- */
  var bound = false;

  document.addEventListener('DOMContentLoaded', function () {
    /* گارد در برای دوبار اجرا شدنِ رویداد (مثلاً در محیط تست):
       شنونده‌های واگذارشده نباید دوباره بسته شوند. */
    if (bound) return;
    bound = true;

    ZZ.shell({ active: 'booking' });

    /* CSS با این کلاس برای نوار چسبانِ پایین، جا باز می‌کند */
    document.body.classList.add('on-booking');

    /* اگر بک‌اند فعال است، تقویم به‌صورت ناهمگام می‌آید.
       این رویداد وقتی داده رسید منتشر می‌شود تا دوباره رندر کنیم. */
    global.addEventListener('zz:calendar', function () {
      if (state.step === 1) {
        renderDays();
        renderSlots();
        updateStep2Button();
      }
    });

    u.$('#doneIcon').innerHTML = ZZ.icon('checkCircle', null, 38);

    /* --- بازیابی وضعیت ---
       پیش‌نویس فقط وقتی استفاده می‌شود که کاربر از صفحه‌ی ورود برگشته
       باشد (?resume=1). ورود تازه به این صفحه همیشه باید از «انتخاب
       خدمت» شروع شود؛ چون پرش ناخواسته به مرحله‌ی بعد برای کاربر گیج‌کننده
       است و گاهی باعث می‌شد با یک خدمتِ تصادفی وارد مرحله‌ی تأیید شود. */
    var resume = u.param('resume') === '1';
    var urlService = u.param('service');

    if (resume) {
      var draft = loadDraft();
      if (draft) {
        state.serviceId = draft.serviceId;
        state.variantId = draft.variantId;
        state.date = draft.date;
        state.time = draft.time;
        state.note = draft.note || '';
      }
    } else {
      clearDraft();
    }

    /* فقط خودِ خدمتِ از قبل انتخاب‌شده را نگه می‌داریم؛ حتی اگر از
       صفحه‌ی خدمت آمده باشید، جریان از مرحله‌ی «انتخاب خدمت» شروع
       می‌شود تا همیشه واضح باشد چه چیزی را انتخاب کرده‌اید. */
    if (urlService && ZZ.services.getById(urlService)) {
      state.serviceId = urlService;
      state.variantId = null;
      state.date = null;
      state.time = null;
    }

    /* --- گام ۱ --- */
    renderServices();
    renderVariants();
    updateStep1Button();

    u.$('#variantChoices').addEventListener('change', function (e) {
      if (e.target.name !== 'variant') return;
      state.variantId = e.target.value;
      updateStep1Button();
      saveDraft();
    });

    /* دکمه‌ی اصلی همه‌ی گام‌ها — در نوار چسبان پایین صفحه */
    u.$('#ctaBtn').addEventListener('click', function () {
      if (this.disabled) return;
      if (state.step === 0) {
        renderDays();
        renderSlots();
        updateStep2Button();
        goStep(1);
      } else if (state.step === 1) {
        renderConfirm();
        goStep(2);
      } else if (state.step === 2) {
        submit();
      }
    });

    /* --- گام ۲ --- */
    u.$('#dayStrip').addEventListener('click', function (e) {
      var chip = e.target.closest('.day-chip');
      if (!chip || chip.disabled) return;
      u.$$('.day-chip', e.currentTarget).forEach(function (c) { c.classList.remove('is-selected'); });
      chip.classList.add('is-selected');
      state.date = chip.dataset.date;
      state.time = null;
      renderSlots();
      updateStep2Button();
      saveDraft();
    });

    u.$('#slotGrid').addEventListener('click', function (e) {
      var slot = e.target.closest('.slot');
      if (!slot || slot.disabled) return;
      u.$$('.slot', e.currentTarget).forEach(function (c) { c.classList.remove('is-selected'); });
      slot.classList.add('is-selected');
      state.time = slot.dataset.time;
      updateStep2Button();
      saveDraft();
    });

    var noteInput = u.$('#noteInput');
    noteInput.value = state.note;
    noteInput.addEventListener('input', u.debounce(function () {
      state.note = noteInput.value.trim();
      saveDraft();
    }, 400));

    u.$('#backToServiceBtn').addEventListener('click', function () { goStep(0); });

    /* --- گام ۳ --- */
    u.$('#backToTimeBtn').addEventListener('click', function () {
      renderDays();
      renderSlots();
      updateStep2Button();
      goStep(1);
    });

    /* --- پرش به مرحله‌ی درست ---
       فقط بعد از برگشت واقعی از صفحه‌ی ورود (?resume=1) به مرحله‌ی
       بعد می‌پریم. در حالت عادی همیشه از «انتخاب خدمت» شروع می‌شود. */
    var target = 0;
    if (resume && state.serviceId && state.variantId) {
      target = 1;
      renderDays();
      renderSlots();
      updateStep2Button();
      if (state.date && state.time) {
        target = 2;
        renderConfirm();
      }
    }
    goStep(target);

    /* اگر تازه از صفحه‌ی ورود برگشته و همه‌چیز آماده است، خبر بده */
    if (resume && ZZ.auth.isLoggedIn() && state.date && state.time) {
      ZZ.toast.info('وارد شدید — حالا نوبتتان را ثبت کنید');
    }
  });
})(window);

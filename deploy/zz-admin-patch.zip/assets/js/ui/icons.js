/* ==========================================================================
   icons.js — آیکون‌های SVG درون‌خطی (سبک، بدون درخواست شبکه)
   ========================================================================== */
(function (global) {
  'use strict';

  var ZZ = (global.ZZ = global.ZZ || {});

  var P = 'stroke="currentColor" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"';

  var paths = {
    /* برند: چشم با مژه */
    logo: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z" ' + P + '/>' +
          '<circle cx="12" cy="12" r="2.6" ' + P + '/>' +
          '<path d="M12 4.2V2M6.2 5.6 5 3.9M17.8 5.6 19 3.9" ' + P + '/>',

    lash:  '<path d="M2.5 13.5c3-4 6.2-6 9.5-6s6.5 2 9.5 6" ' + P + '/>' +
           '<path d="M4.6 12.2 3 15.6M8.6 9.6 7.7 13.4M12 8.7v4M15.4 9.6l.9 3.8M19.4 12.2 21 15.6" ' + P + '/>',

    liner: '<path d="M3 15.5c3-4.5 6-6.8 9-6.8s6 2.3 9 6.8" ' + P + '/>' +
           '<path d="m14.6 5.2 3.4 3.4M18.4 3.6a1.6 1.6 0 0 1 2.3 2.3l-6.6 6.6-3 .7.7-3z" ' + P + '/>',

    /* لب: کمان بالا با فرو‌رفتگی وسط + کمان پایین پرتر */
    lip:   '<path d="M3.2 11.4c1.6-2.5 3.4-3.8 5-3.8 1.5 0 2.6.8 3.8 1.9 1.2-1.1 2.3-1.9 3.8-1.9 1.6 0 3.4 1.3 5 3.8" ' + P + '/>' +
           '<path d="M3.2 11.4c1.9 3.3 5 5 8.8 5s6.9-1.7 8.8-5" ' + P + '/>' +
           '<path d="M3.2 11.4h17.6" ' + P + ' opacity="0.45"/>',

    lift:  '<path d="M3 16c3-5 6-7.5 9-7.5s6 2.5 9 7.5" ' + P + '/>' +
           '<path d="M12 6.5V2.8M12 2.8 9.9 5M12 2.8 14.1 5" ' + P + '/>' +
           '<circle cx="12" cy="16" r="1" fill="currentColor" stroke="none"/>',

    clock: '<circle cx="12" cy="12" r="9" ' + P + '/><path d="M12 7.5V12l3 1.8" ' + P + '/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2.5" ' + P + '/>' +
              '<path d="M3 10h18M8 3v4M16 3v4" ' + P + '/>',
    calendarDays: '<rect x="3" y="5" width="18" height="16" rx="2.5" ' + P + '/>' +
                  '<path d="M3 10h18M8 3v4M16 3v4" ' + P + '/>' +
                  '<circle cx="8.2" cy="13.7" r="0.9" fill="currentColor" stroke="none"/>' +
                  '<circle cx="12" cy="13.7" r="0.9" fill="currentColor" stroke="none"/>' +
                  '<circle cx="15.8" cy="13.7" r="0.9" fill="currentColor" stroke="none"/>' +
                  '<circle cx="8.2" cy="17.4" r="0.9" fill="currentColor" stroke="none"/>' +
                  '<circle cx="12" cy="17.4" r="0.9" fill="currentColor" stroke="none"/>' +
                  '<circle cx="15.8" cy="17.4" r="0.9" fill="currentColor" stroke="none"/>',
    tag:   '<path d="M3 12.4V4.6A1.6 1.6 0 0 1 4.6 3h7.8a1.6 1.6 0 0 1 1.1.5l7 7a1.6 1.6 0 0 1 0 2.3l-7.6 7.6a1.6 1.6 0 0 1-2.3 0l-7-7a1.6 1.6 0 0 1-.6-1z" ' + P + '/>' +
           '<circle cx="7.6" cy="7.6" r="1.2" ' + P + '/>',
    user:  '<circle cx="12" cy="8" r="3.8" ' + P + '/><path d="M4.5 20.2a7.7 7.7 0 0 1 15 0" ' + P + '/>',
    phone: '<path d="M6.2 3.5h3l1.6 4-2 1.4a12 12 0 0 0 5.8 5.8l1.4-2 4 1.6v3a1.7 1.7 0 0 1-1.9 1.7A16.8 16.8 0 0 1 4.5 5.4 1.7 1.7 0 0 1 6.2 3.5z" ' + P + '/>',
    pin:   '<path d="M12 21s7-5.7 7-11a7 7 0 1 0-14 0c0 5.3 7 11 7 11z" ' + P + '/><circle cx="12" cy="10" r="2.6" ' + P + '/>',
    check: '<path d="m4.5 12.5 5 5 10-11" ' + P + '/>',
    checkCircle: '<circle cx="12" cy="12" r="9" ' + P + '/><path d="m8 12.3 2.7 2.7L16 9.5" ' + P + '/>',
    alert: '<circle cx="12" cy="12" r="9" ' + P + '/><path d="M12 7.5v5.2M12 16.4v.1" ' + P + '/>',
    info:  '<circle cx="12" cy="12" r="9" ' + P + '/><path d="M12 11v5.5M12 7.6v.1" ' + P + '/>',
    x:     '<path d="M6 6l12 12M18 6 6 18" ' + P + '/>',
    arrowLeft:  '<path d="M19 12H5M11 6l-6 6 6 6" ' + P + '/>',
    arrowRight: '<path d="M5 12h14M13 6l6 6-6 6" ' + P + '/>',
    chevronLeft: '<path d="M15 5l-7 7 7 7" ' + P + '/>',
    chevronDown: '<path d="m5 9 7 7 7-7" ' + P + '/>',
    sparkle: '<path d="M12 3.2 13.6 9 19.4 10.6 13.6 12.2 12 18 10.4 12.2 4.6 10.6 10.4 9z" ' + P + '/>' +
             '<path d="M18.6 16.2 19.3 18.5 21.6 19.2 19.3 19.9 18.6 22.2 17.9 19.9 15.6 19.2 17.9 18.5z" ' + P + '/>',
    shield: '<path d="M12 3 5 6v6c0 4.3 3 7.7 7 9 4-1.3 7-4.7 7-9V6z" ' + P + '/><path d="m9.2 12 2 2 3.6-4" ' + P + '/>',
    heart: '<path d="M12 20s-7.5-4.7-7.5-10A4.2 4.2 0 0 1 12 7.4 4.2 4.2 0 0 1 19.5 10c0 5.3-7.5 10-7.5 10z" ' + P + '/>',
    /* جام / نشان افتخار — برای سابقه‌ی کاری */
    award: '<path d="M7.5 3.5h9v5a4.5 4.5 0 0 1-9 0z" ' + P + '/>' +
           '<path d="M7.5 5H5a2 2 0 0 0 2.4 2M16.5 5H19a2 2 0 0 1-2.4 2" ' + P + '/>' +
           '<path d="M12 13v3.5M9 20.5h6M10.5 16.5h3l.6 4h-4.2z" ' + P + '/>',

    /* شبکه — برای دکمه‌ی خدمات */
    grid:  '<rect x="3.5" y="3.5" width="7" height="7" rx="1.6" ' + P + '/>' +
           '<rect x="13.5" y="3.5" width="7" height="7" rx="1.6" ' + P + '/>' +
           '<rect x="3.5" y="13.5" width="7" height="7" rx="1.6" ' + P + '/>' +
           '<rect x="13.5" y="13.5" width="7" height="7" rx="1.6" ' + P + '/>',

    map:   '<path d="M9 3.5 3.5 5.8v14.7L9 18.2l6 2.3 5.5-2.3V3.5L15 5.8z" ' + P + '/>' +
           '<path d="M9 3.5v14.7M15 5.8v14.7" ' + P + '/>',

    /* گفت‌وگو / مشاوره */
    chat:  '<path d="M20.5 12.2c0 4-3.8 7.2-8.5 7.2a9.8 9.8 0 0 1-2.7-.37L4.5 20.5l1.5-3.7A6.9 6.9 0 0 1 3.5 12.2C3.5 8.2 7.3 5 12 5s8.5 3.2 8.5 7.2z" ' + P + '/>' +
           '<path d="M8.6 12h.01M12 12h.01M15.4 12h.01" ' + P + '/>',

    /* تماس در حال زنگ خوردن */
    phoneCall: '<path d="M7 3.6h2.6l1.4 3.5-1.75 1.2a10.5 10.5 0 0 0 5.05 5.05l1.2-1.75 3.5 1.4V16a1.5 1.5 0 0 1-1.65 1.5A14.7 14.7 0 0 1 5.5 5.25 1.5 1.5 0 0 1 7 3.6z" ' + P + '/>',

    instagram: '<rect x="3" y="3" width="18" height="18" rx="5" ' + P + '/>' +
               '<circle cx="12" cy="12" r="4" ' + P + '/><circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none"/>',
    whatsapp: '<path d="M3.5 20.5 5 16.4A8 8 0 1 1 8 19.2z" ' + P + '/>' +
              '<path d="M9 9.4c.2 2.6 2.6 4.9 5.2 5.1.7 0 1.3-.5 1.4-1.2l-1.9-.9-.9 1a6 6 0 0 1-2.6-2.6l1-.9-.9-1.9c-.7.1-1.3.7-1.3 1.4z" ' + P + '/>',
    telegram: '<path d="m21 4.5-3 15-6-4.5-3 3v-4.5l9-7.5-10.5 6L3 10.5z" ' + P + '/>',
    logout: '<path d="M9 21H5.5A1.5 1.5 0 0 1 4 19.5v-15A1.5 1.5 0 0 1 5.5 3H9M15.5 16.5 20 12l-4.5-4.5M20 12H9" ' + P + '/>',
    edit: '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3z" ' + P + '/>',
    empty: '<path d="M4 8.5 12 4l8 4.5v7L12 20l-8-4.5z" ' + P + '/><path d="M4 8.5 12 13l8-4.5M12 13v7" ' + P + '/>',
    plus: '<path d="M12 5v14M5 12h14" ' + P + '/>'
  };

  /**
   * @param {string} name نام آیکون
   * @param {string} cls کلاس CSS
   * @param {number} size اندازه (پیش‌فرض ۲۴)
   */
  ZZ.icon = function (name, cls, size) {
    var d = paths[name] || paths.info;
    var s = size || 24;
    return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" aria-hidden="true" focusable="false"' +
           (cls ? ' class="' + cls + '"' : '') + '>' + d + '</svg>';
  };

  ZZ.iconNames = Object.keys(paths);
})(window);
